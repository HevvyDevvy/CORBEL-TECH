import socket

from crypto import (
    generate_ephemeral_keypair,
    public_key_to_bytes,
    sign_ephemeral_key,
    verify_ephemeral_key,
    derive_shared_key,
    load_identity,
    load_trusted_peer,
    encrypt_aes,
)
from utils import compress, xor, send_framed, recv_framed
from cryptography.exceptions import InvalidSignature


def send_message(host: str, port: int, peer_name: str, plaintext: bytes) -> None:
    """Connect to a listener, perform the authenticated handshake, and
    send one encrypted message."""
    identity_private_key = load_identity()
    peer_identity_public_key = load_trusted_peer(peer_name)

    eph_private, eph_public = generate_ephemeral_keypair()
    eph_public_bytes = public_key_to_bytes(eph_public)
    signature = sign_ephemeral_key(identity_private_key, eph_public_bytes)

    with socket.create_connection((host, port), timeout=10) as sock:
        send_framed(sock, eph_public_bytes)
        send_framed(sock, signature)

        # The peer proves itself back the same way.
        peer_eph_public_bytes = recv_framed(sock)
        peer_signature = recv_framed(sock)
        try:
            verify_ephemeral_key(peer_identity_public_key, peer_eph_public_bytes, peer_signature)
        except InvalidSignature as e:
            raise RuntimeError(
                f"Handshake failed: '{peer_name}' did not sign with the trusted identity key. "
                "Aborting -- this may be a MITM attempt."
            ) from e

        shared_key = derive_shared_key(eph_private, peer_eph_public_bytes)

        compressed = compress(plaintext)
        obfuscated = xor(compressed)
        encrypted = encrypt_aes(shared_key, obfuscated)

        send_framed(sock, encrypted)


if __name__ == "__main__":
    import sys

    if len(sys.argv) != 5:
        print("Usage: python sender.py <host> <port> <trusted-peer-name> <message>")
        sys.exit(1)

    host, port, peer_name, message = sys.argv[1], int(sys.argv[2]), sys.argv[3], sys.argv[4]
    send_message(host, port, peer_name, message.encode())
    print("Sent.")
