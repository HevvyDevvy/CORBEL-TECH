import random
import socket


def get_random_port(port_range=(40000, 60000)) -> int:
    """Find an ephemeral port that's actually free to bind, within the
    configured range (see config.json's port_range)."""
    low, high = port_range
    for _ in range(100):
        port = random.randint(low, high)
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            try:
                s.bind(("0.0.0.0", port))
                return port
            except OSError:
                continue
    raise RuntimeError("No free port found in range")
