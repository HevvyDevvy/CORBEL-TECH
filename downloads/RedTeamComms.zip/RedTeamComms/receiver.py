import socket

from crypto import (
    generate_ephemeral_keypair,
    public_key_to_bytes,
    sign_ephemeral_key,
    verify_ephemeral_key,
    derive_shared_key,
    load_identity,
    load_trusted_peer,
    decrypt_aes,
)
from utils import decompress, deobfuscate, send_framed, recv_framed
from cryptography.exceptions import InvalidSignature


def listen(port: int, peer_name: str, on_message=print) -> None:
    """Bind, accept one connection, complete the authenticated
    handshake, and decrypt one incoming message. Call in a loop for a
    persistent listener."""
    identity_private_key = load_identity()
    peer_identity_public_key = load_trusted_peer(peer_name)

    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as srv:
        srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        srv.bind(("0.0.0.0", port))
        srv.listen(1)
        conn, addr = srv.accept()

        with conn:
            peer_eph_public_bytes = recv_framed(conn)
            peer_signature = recv_framed(conn)
            try:
                verify_ephemeral_key(peer_identity_public_key, peer_eph_public_bytes, peer_signature)
            except InvalidSignature as e:
                raise RuntimeError(
                    f"Handshake failed: connection from {addr} did not sign with "
                    f"'{peer_name}'s trusted identity key. Aborting -- possible MITM."
                ) from e

            eph_private, eph_public = generate_ephemeral_keypair()
            eph_public_bytes = public_key_to_bytes(eph_public)
            signature = sign_ephemeral_key(identity_private_key, eph_public_bytes)
            send_framed(conn, eph_public_bytes)
            send_framed(conn, signature)

            shared_key = derive_shared_key(eph_private, peer_eph_public_bytes)

            encrypted = recv_framed(conn)
            obfuscated = decrypt_aes(shared_key, encrypted)
            compressed = deobfuscate(obfuscated)
            plaintext = decompress(compressed)

            on_message(plaintext)


if __name__ == "__main__":
    import sys

    if len(sys.argv) != 3:
        print("Usage: python receiver.py <port> <trusted-peer-name>")
        sys.exit(1)

    listen(int(sys.argv[1]), sys.argv[2], on_message=lambda m: print("Received:", m))
