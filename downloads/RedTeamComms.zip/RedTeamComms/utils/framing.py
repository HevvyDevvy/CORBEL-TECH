"""Length-prefixed framing over a raw TCP socket.

The original code did a single `conn.recv(4096)` and assumed the whole
message arrived in one call -- TCP doesn't guarantee that, especially
for anything larger than one packet (e.g. file transfers). This sends
a 4-byte big-endian length prefix before each piece of data and reads
exactly that many bytes back.
"""
import struct


def send_framed(sock, data: bytes) -> None:
    sock.sendall(struct.pack(">I", len(data)) + data)


def recv_exact(sock, n: int) -> bytes:
    buf = b""
    while len(buf) < n:
        chunk = sock.recv(n - len(buf))
        if not chunk:
            raise ConnectionError("Socket closed before expected data was received")
        buf += chunk
    return buf


def recv_framed(sock) -> bytes:
    (length,) = struct.unpack(">I", recv_exact(sock, 4))
    return recv_exact(sock, length)
