"""Traffic obfuscation to make packet contents less recognizable on the
wire. Note: this is NOT a security layer -- AES-GCM in aes.py provides
the actual confidentiality/integrity. This just reduces the chance of
naive DPI pattern-matching flagging the traffic, applied inside the
encrypted envelope for that reason only.
"""


def xor(data: bytes, key: int = 0xAA) -> bytes:
    return bytes(b ^ key for b in data)


# xor is a self-inverse operation, so the same function deobfuscates.
deobfuscate = xor
