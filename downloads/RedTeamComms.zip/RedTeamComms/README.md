# RedTeamComms

Encrypted point-to-point messaging over raw TCP sockets: AES-256-GCM
for the payload, X25519 for ephemeral key exchange, Ed25519 long-term
identities to authenticate that exchange, gzip + XOR obfuscation on top.

Not SMTP, not email — this is its own protocol.

## Setup (once per device)

```bash
pip install -r requirements.txt

python cli.py init-identity
python cli.py fingerprint
# Read the fingerprint to your peer over a channel you already trust
# (in person, voice call) — exactly like verifying a Signal safety number.

python cli.py trust-peer <their-name> <their-fingerprint-hex>
```

## Send / receive

```bash
# On the receiving device:
python cli.py listen --port 5005 --peer <sender-name>

# On the sending device:
python cli.py send --host <receiver-ip> --port 5005 --peer <receiver-name> --message "hi"
```

## What was fixed from the original

- **Broken on import** — `crypto/__init__.py`, `utils/__init__.py`, and `ports/__init__.py` re-exported function names that didn't exist in the actual modules (`encrypt_data` vs. the real `encrypt_aes`, etc.). Fixed to match.
- **No authentication on the key exchange** — the original sent a fresh, unsigned ECDH public key over the same channel every session, so anyone on-path could substitute their own key and silently MITM the conversation. Added long-term Ed25519 identity keys (`crypto/identity.py`) that sign every session's ephemeral X25519 key; the peer verifies the signature before deriving a shared secret. This requires a one-time out-of-band fingerprint check (see Setup) — there's no way to bootstrap trust purely over the same network you're trying to secure, so that step isn't optional.
- **AES-CBC with no MAC** — vulnerable to padding-oracle attacks and undetected ciphertext tampering. Replaced with AES-256-GCM (authenticated encryption — confidentiality and integrity together).
- **Fragile single `recv(4096)`** — TCP doesn't guarantee a whole message arrives in one read. Added length-prefixed framing (`utils/framing.py`).
- **`public_key.public_bytes()` called with no arguments** — the `cryptography` library requires explicit encoding/format args; this would have raised `TypeError` immediately. Fixed.
- `config.json`'s `ecc_curve` said `secp521r1` while the code used X25519 — corrected to match reality.

## Note on the obfuscation layer

The XOR pass adds no real security on its own (single-byte XOR is trivially reversible) — it's applied to reduce naive pattern-matching on the wire, entirely underneath the AES-GCM layer that provides the actual security. Don't rely on it for anything.
