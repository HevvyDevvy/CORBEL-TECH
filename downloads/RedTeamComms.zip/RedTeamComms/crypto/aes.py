"""AES-GCM encryption — authenticated encryption (confidentiality +
integrity in one step), replacing the original AES-CBC-with-no-MAC
scheme, which had no protection against ciphertext tampering.
"""
import base64
import os

from cryptography.hazmat.primitives.ciphers.aead import AESGCM

KEY_LENGTH = 32  # AES-256
NONCE_LENGTH = 12  # standard for GCM


def generate_aes_key() -> bytes:
    return os.urandom(KEY_LENGTH)


def encrypt_aes(key: bytes, plaintext: bytes, associated_data: bytes = b"") -> bytes:
    """Returns base64(nonce || ciphertext_with_tag)."""
    aesgcm = AESGCM(key)
    nonce = os.urandom(NONCE_LENGTH)
    ciphertext = aesgcm.encrypt(nonce, plaintext, associated_data)
    return base64.b64encode(nonce + ciphertext)


def decrypt_aes(key: bytes, blob: bytes, associated_data: bytes = b"") -> bytes:
    raw = base64.b64decode(blob)
    nonce, ciphertext = raw[:NONCE_LENGTH], raw[NONCE_LENGTH:]
    aesgcm = AESGCM(key)
    return aesgcm.decrypt(nonce, ciphertext, associated_data)
