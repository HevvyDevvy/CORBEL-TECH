"""Ephemeral X25519 key exchange, authenticated by a long-term Ed25519
identity signature (see identity.py). Each session:

    1. Generates a fresh ephemeral X25519 keypair (forward secrecy).
    2. Signs the ephemeral public key with the long-term identity key.
    3. Sends {ephemeral_public_key, signature}.
    4. The peer verifies the signature against the *already-trusted*
       identity public key before deriving the shared secret.

Without step 4 this is exactly the original code's vulnerability: an
on-path attacker can swap in their own ephemeral key.
"""
from cryptography.hazmat.primitives.asymmetric import x25519
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.exceptions import InvalidSignature

PUBLIC_KEY_LENGTH = 32  # raw X25519 public key length


def generate_ephemeral_keypair():
    private_key = x25519.X25519PrivateKey.generate()
    public_key = private_key.public_key()
    return private_key, public_key


def public_key_to_bytes(public_key: x25519.X25519PublicKey) -> bytes:
    return public_key.public_bytes(
        encoding=serialization.Encoding.Raw, format=serialization.PublicFormat.Raw
    )


def sign_ephemeral_key(identity_private_key: Ed25519PrivateKey, ephemeral_public_bytes: bytes) -> bytes:
    return identity_private_key.sign(ephemeral_public_bytes)


def verify_ephemeral_key(
    peer_identity_public_key: Ed25519PublicKey,
    ephemeral_public_bytes: bytes,
    signature: bytes,
) -> None:
    """Raises cryptography.exceptions.InvalidSignature if the signature
    doesn't match -- callers must not proceed to derive a shared key if
    this raises."""
    peer_identity_public_key.verify(signature, ephemeral_public_bytes)


def derive_shared_key(private_key: x25519.X25519PrivateKey, peer_public_bytes: bytes) -> bytes:
    peer_public = x25519.X25519PublicKey.from_public_bytes(peer_public_bytes)
    shared = private_key.exchange(peer_public)
    return HKDF(
        algorithm=hashes.SHA256(),
        length=32,
        salt=None,
        info=b"RedTeamComms-v2",
    ).derive(shared)


__all__ = [
    "InvalidSignature",
    "generate_ephemeral_keypair",
    "public_key_to_bytes",
    "sign_ephemeral_key",
    "verify_ephemeral_key",
    "derive_shared_key",
    "PUBLIC_KEY_LENGTH",
]
