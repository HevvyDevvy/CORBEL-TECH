"""Long-term identity keys.

The original ECDH exchange sent a fresh, unsigned public key over the
same untrusted channel every session -- anyone on-path could swap in
their own key and MITM the whole conversation. Fixing that requires a
long-term identity that's verified out-of-band once, then used to sign
every session's ephemeral key from then on. This module manages that
identity.

Setup (once per device, out of band):
    1. Each side runs `generate_identity()` and gets a fingerprint.
    2. Compare fingerprints over a channel you already trust (in person,
       voice call, whatever your OpSec course covers for this) --
       exactly like verifying a Signal safety number.
    3. Each side saves the other's public identity key with
       `trust_peer_identity()`.

Skipping step 2 and just exchanging keys over the same network you're
trying to secure defeats the point -- the trust has to come from
somewhere outside the channel.
"""
import json
import os
from pathlib import Path

from cryptography.hazmat.primitives.asymmetric.ed25519 import (
    Ed25519PrivateKey,
    Ed25519PublicKey,
)
from cryptography.hazmat.primitives import serialization

IDENTITY_DIR = Path(os.environ.get("REDTEAMCOMMS_HOME", Path.home() / ".redteamcomms"))
IDENTITY_KEY_PATH = IDENTITY_DIR / "identity_key.pem"
TRUSTED_PEERS_PATH = IDENTITY_DIR / "trusted_peers.json"


def generate_identity() -> Ed25519PrivateKey:
    IDENTITY_DIR.mkdir(parents=True, exist_ok=True, mode=0o700)
    private_key = Ed25519PrivateKey.generate()
    pem = private_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption(),
    )
    IDENTITY_KEY_PATH.write_bytes(pem)
    os.chmod(IDENTITY_KEY_PATH, 0o600)
    return private_key


def load_identity() -> Ed25519PrivateKey:
    if not IDENTITY_KEY_PATH.exists():
        raise FileNotFoundError(
            f"No identity key at {IDENTITY_KEY_PATH}. Run generate_identity() first."
        )
    pem = IDENTITY_KEY_PATH.read_bytes()
    return serialization.load_pem_private_key(pem, password=None)


def fingerprint(public_key: Ed25519PublicKey) -> str:
    raw = public_key.public_bytes(
        encoding=serialization.Encoding.Raw, format=serialization.PublicFormat.Raw
    )
    return raw.hex()


def trust_peer_identity(peer_name: str, peer_public_key_hex: str) -> None:
    """Record a peer's identity public key after verifying its
    fingerprint out-of-band. Overwrites any previous entry for the same
    name -- re-verify before doing so."""
    IDENTITY_DIR.mkdir(parents=True, exist_ok=True, mode=0o700)
    peers = {}
    if TRUSTED_PEERS_PATH.exists():
        peers = json.loads(TRUSTED_PEERS_PATH.read_text())
    peers[peer_name] = peer_public_key_hex
    TRUSTED_PEERS_PATH.write_text(json.dumps(peers, indent=2))
    os.chmod(TRUSTED_PEERS_PATH, 0o600)


def load_trusted_peer(peer_name: str) -> Ed25519PublicKey:
    if not TRUSTED_PEERS_PATH.exists():
        raise FileNotFoundError(f"No trusted peers file at {TRUSTED_PEERS_PATH}.")
    peers = json.loads(TRUSTED_PEERS_PATH.read_text())
    if peer_name not in peers:
        raise KeyError(f"No trusted identity stored for '{peer_name}'.")
    raw = bytes.fromhex(peers[peer_name])
    return Ed25519PublicKey.from_public_bytes(raw)
