#!/usr/bin/env python3
"""RedTeamComms CLI -- identity setup, trust management, send/listen.

One-time setup per device:
    python cli.py init-identity
    python cli.py fingerprint          # read this to your peer over a trusted channel
    python cli.py trust-peer alice <their-fingerprint-hex>

Then:
    python cli.py listen --port 5005 --peer alice
    python cli.py send --host 1.2.3.4 --port 5005 --peer alice --message "hi"
"""
import argparse

from crypto import generate_identity, load_identity, fingerprint, trust_peer_identity
from sender import send_message
from receiver import listen


def main():
    parser = argparse.ArgumentParser(prog="redteamcomms")
    sub = parser.add_subparsers(dest="command", required=True)

    sub.add_parser("init-identity", help="Generate this device's long-term identity key")
    sub.add_parser("fingerprint", help="Print this device's identity fingerprint")

    trust_parser = sub.add_parser("trust-peer", help="Record a peer's verified identity fingerprint")
    trust_parser.add_argument("name")
    trust_parser.add_argument("fingerprint_hex")

    send_parser = sub.add_parser("send", help="Send an encrypted message")
    send_parser.add_argument("--host", required=True)
    send_parser.add_argument("--port", type=int, required=True)
    send_parser.add_argument("--peer", required=True, help="Trusted peer name")
    send_parser.add_argument("--message", required=True)

    listen_parser = sub.add_parser("listen", help="Listen for one incoming encrypted message")
    listen_parser.add_argument("--port", type=int, required=True)
    listen_parser.add_argument("--peer", required=True, help="Trusted peer name")

    args = parser.parse_args()

    if args.command == "init-identity":
        generate_identity()
        print("Identity generated. Run 'fingerprint' and share it with your peer out-of-band.")
    elif args.command == "fingerprint":
        print(fingerprint(load_identity().public_key()))
    elif args.command == "trust-peer":
        trust_peer_identity(args.name, args.fingerprint_hex)
        print(f"Trusted '{args.name}'.")
    elif args.command == "send":
        send_message(args.host, args.port, args.peer, args.message.encode())
        print("Sent.")
    elif args.command == "listen":
        print(f"Listening on 0.0.0.0:{args.port} for a message from '{args.peer}'...")
        listen(args.port, args.peer, on_message=lambda m: print("Received:", m.decode(errors="replace")))


if __name__ == "__main__":
    main()
