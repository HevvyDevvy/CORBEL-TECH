# Cisco IOS — Quick-Fire Commands

Router/switch CLI (IOS/IOS-XE).

#### 1. Modes & Navigation

```
Router>                    enable mode (user exec)
Router> enable
Router#                    privileged exec
Router# configure terminal
Router(config)#            global config
Router(config-if)#         interface config
Router(config-line)#       line config (console/vty)
end / exit                 back out a level (or all the way with `end`)
```

#### 2. Basic Device Info

```
show version
show running-config
show startup-config
show inventory
show processes cpu
show memory statistics
```

#### 3. Interfaces

```
interface GigabitEthernet0/1
 description Uplink-to-Core
 ip address 192.168.1.1 255.255.255.0
 no shutdown
exit

show ip interface brief
show interfaces status
show interfaces GigabitEthernet0/1
```

#### 4. VLANs & Trunking

```
vlan 10
 name SALES
exit

interface GigabitEthernet0/2
 switchport mode access
 switchport access vlan 10
exit

interface GigabitEthernet0/24
 switchport mode trunk
 switchport trunk allowed vlan 10,20,30
exit

show vlan brief
show interfaces trunk
```

#### 5. Routing

```
ip route 0.0.0.0 0.0.0.0 192.168.1.254

router ospf 1
 network 192.168.1.0 0.0.0.255 area 0
exit

show ip route
show ip ospf neighbor
show ip protocols
```

#### 6. ACLs

```
ip access-list extended BLOCK_TELNET
 deny tcp any any eq 23
 permit ip any any
exit

interface GigabitEthernet0/1
 ip access-group BLOCK_TELNET in
exit

show access-lists
```

#### 7. AAA / Security Baseline

```
enable secret <strong-secret>
service password-encryption

line console 0
 password <console-password>
 login
exit

line vty 0 4
 transport input ssh
 login local
exit

username admin privilege 15 secret <strong-secret>

ip ssh version 2
crypto key generate rsa modulus 2048
```

#### 8. Save & Backup

```
copy running-config startup-config
write memory
copy running-config tftp:
copy startup-config flash:backup-config.txt
```

#### 9. Diagnostics

```
ping 8.8.8.8
traceroute 8.8.8.8
show cdp neighbors detail
show mac address-table
show spanning-tree
debug ip packet          (use sparingly -- can flood console on busy links)
undebug all               (turn all debugging off)
```

#### 10. Useful One-Liners

```
show ip interface brief | exclude unassigned
show running-config | section interface GigabitEthernet0/1
show logging | include %LINK
```
