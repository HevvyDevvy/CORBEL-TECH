# Juniper JunOS — Quick-Fire Commands

#### 1. Modes & Navigation

```
user@router>                operational mode
user@router> configure
user@router#                configuration mode
edit interfaces ge-0/0/0     step into a config hierarchy
top                          jump back to config root
exit                         leave configuration mode
```

#### 2. Basic Device Info

```
show version
show chassis hardware
show system uptime
show system processes extensive
```

#### 3. Interfaces

```
edit interfaces ge-0/0/0
set unit 0 family inet address 192.168.1.1/24
top
commit

show interfaces terse
show interfaces ge-0/0/0 extensive
```

#### 4. VLANs

```
set vlans SALES vlan-id 10
set interfaces ge-0/0/1 unit 0 family ethernet-switching vlan members SALES

show vlans
show ethernet-switching table
```

#### 5. Routing

```
set routing-options static route 0.0.0.0/0 next-hop 192.168.1.254

set protocols ospf area 0.0.0.0 interface ge-0/0/0.0

show route
show ospf neighbor
show route protocol static
```

#### 6. Firewall Filters (ACL equivalent)

```
set firewall filter BLOCK_TELNET term deny-telnet from protocol tcp
set firewall filter BLOCK_TELNET term deny-telnet from destination-port 23
set firewall filter BLOCK_TELNET term deny-telnet then discard
set firewall filter BLOCK_TELNET term allow-rest then accept

set interfaces ge-0/0/0 unit 0 family inet filter input BLOCK_TELNET

show firewall filter BLOCK_TELNET
```

#### 7. Security Baseline

```
set system root-authentication encrypted-password "<hash>"
set system services ssh root-login deny
set system login user admin class super-user authentication plain-text-password

set system services ssh protocol-version v2
```

#### 8. Commit Workflow (JunOS's key differentiator)

```
commit check                 # validate without applying
commit confirmed 5           # apply, auto-rollback in 5 min unless confirmed
commit                       # confirm/finalize
rollback 1                   # revert to previous committed config
show | compare               # diff candidate vs active config
```

#### 9. Diagnostics

```
ping 8.8.8.8
traceroute 8.8.8.8
show system alarms
show chassis alarms
monitor traffic interface ge-0/0/0
```

#### 10. Save & Backup

```
save /var/tmp/backup-config.conf
show configuration | display set   # export as `set` commands (portable across devices)
```
