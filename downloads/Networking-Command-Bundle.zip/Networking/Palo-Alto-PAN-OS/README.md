# Palo Alto Networks (PAN-OS) — Quick-Fire Commands

#### 1. Modes & Navigation

```
admin@PA-VM>                    operational mode
admin@PA-VM> configure
admin@PA-VM#                    configuration mode
set / edit / delete             config verbs
commit                          apply candidate config
exit
```

#### 2. Basic Device Info

```
show system info
show system resources
show high-availability state
request system software info
```

#### 3. Interfaces & Zones

```
set network interface ethernet ethernet1/1 layer3 ip 192.168.1.1/24
set zone trust network layer3 ethernet1/1

show interface ethernet1/1
show zone
```

#### 4. Security Policies

```
set rulebase security rules ALLOW-WEB from trust to untrust source any destination any application web-browsing action allow
set rulebase security rules ALLOW-WEB log-end yes

show running security-policy
test security-policy-match from trust to untrust destination-port 443 protocol 6
```

#### 5. NAT

```
set rulebase nat rules OUTBOUND-NAT from trust to untrust source any destination any service any source-translation dynamic-ip-and-port interface-address interface ethernet1/1

show running nat-policy
```

#### 6. Threat Prevention

```
set profiles vulnerability HIGH-SEC rules default action reset-both severity critical
set profiles vulnerability HIGH-SEC rules default action reset-both severity high

show threat vulnerability
show counter global filter severity drop
```

#### 7. VPN

```
show vpn ipsec-sa
show vpn flow
show vpn gateway
test vpn ipsec-sa tunnel <tunnel-name>
```

#### 8. Logging & Diagnostics

```
show log traffic direction equal backward
show log threat direction equal backward

tail follow yes mp-log ms.log
debug dataplane packet-diag set capture stage receive file rx.pcap
```

#### 9. Config Management

```
save config to backup-config.xml
load config from backup-config.xml
commit force
show config running
```

#### 10. Useful One-Liners

```
show session all filter source 192.168.1.10
show system state filter-pretty sys.s1.p8.stats
request system fqdn refresh all
```
