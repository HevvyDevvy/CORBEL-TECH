# Aruba (ArubaOS-CX) — Quick-Fire Commands

#### 1. Modes & Navigation

```
switch>                     operator mode
switch> enable
switch#                     manager mode
switch# configure terminal
switch(config)#             global config
switch(config-if)#          interface config
end / exit
```

#### 2. Basic Device Info

```
show version
show system
show running-config
show module
```

#### 3. Interfaces

```
interface 1/1/1
 description Uplink
 no shutdown
 ip address 192.168.1.1/24
exit

show interface 1/1/1
show interface brief
```

#### 4. VLANs

```
vlan 10
 name SALES
exit

interface 1/1/2
 no routing
 vlan access 10
exit

show vlan
show vlan 10
```

#### 5. Routing

```
ip route 0.0.0.0/0 192.168.1.254

router ospf 1
 area 0.0.0.0
exit

show ip route
show ip ospf neighbor
```

#### 6. Access Control Lists

```
access-list ip BLOCK_TELNET
 10 deny tcp any any eq telnet
 20 permit any any
exit

interface 1/1/1
 apply access-list ip BLOCK_TELNET in
exit

show access-list
```

#### 7. Security Baseline

```
user admin group administrators password plaintext <strong-password>

ssh server vrf default
no telnet-server

show ssh server
```

#### 8. Diagnostics

```
ping 8.8.8.8
traceroute 8.8.8.8
show lldp neighbor-info
show mac-address-table
show spanning-tree
```

#### 9. Save & Backup

```
copy running-config startup-config
copy running-config tftp://<server>/backup-config.cfg
```

#### 10. Aruba Central / AP Management (wireless side)

```
show ap database
show ap active
show ap monitor
show wlan client-status
```
