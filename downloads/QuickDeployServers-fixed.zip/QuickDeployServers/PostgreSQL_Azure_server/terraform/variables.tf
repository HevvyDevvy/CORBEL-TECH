variable "resource_group_name" {
  type    = string
  default = "MyPostgreSQLResourceGroup"
}

variable "location" {
  type    = string
  default = "eastus"
}

variable "server_name" {
  type    = string
  default = "mypostgresqlserver"
}

variable "sku_name" {
  description = "e.g. B_Standard_B1ms, GP_Standard_D2s_v3"
  type        = string
  default     = "B_Standard_B1ms"
}

variable "high_availability" {
  type    = bool
  default = false
}

variable "admin_user" {
  type    = string
  default = "myadmin"
}

variable "admin_password" {
  description = "Pass via TF_VAR_admin_password, never commit it."
  type        = string
  sensitive   = true
}

variable "database_name" {
  type    = string
  default = "mydatabase"
}
