# PostgreSQL_Azure_server

Terraform to provision a secure Azure PostgreSQL Flexible Server (private
VNet delegation, enforced SSL, connection/audit logging, 35-day backups),
plus a small Flask service that proves connectivity end-to-end.

## Provision the database

```bash
cd terraform
cp terraform.tfvars.example terraform.tfvars   # fill in your values
export TF_VAR_admin_password="a-strong-password"
terraform init
terraform plan
terraform apply
```

## Run the connectivity check

```bash
cd app
pip install -r requirements.txt
export DB_HOST=$(terraform -chdir=../terraform output -raw server_fqdn)
export DB_NAME=mydatabase
export DB_USER=myadmin
export DB_PASSWORD=<your password>
python app.py
```

`curl http://localhost:8080/db-check` should return `connected: true` with
the server version — confirming the SSL-enforced (`sslmode=require`)
connection actually works against the provisioned instance.

## docs/

`BeforeSC-100.md` and `After4days_SC-100.md` are the original SC-100 study
notes this setup was built from — kept for reference, superseded by the
Terraform in `terraform/`.
