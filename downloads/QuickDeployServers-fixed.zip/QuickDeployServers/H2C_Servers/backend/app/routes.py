from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity

from app import db
from app.models import Service

main_bp = Blueprint("main", __name__)


@main_bp.route("/health", methods=["GET"])
def health():
    return jsonify({"status": "ok"}), 200


@main_bp.route("/api/services", methods=["GET"])
@jwt_required()
def list_services():
    user_id = get_jwt_identity()
    services = Service.query.filter_by(owner_id=user_id).all()
    return jsonify([s.to_dict() for s in services]), 200


@main_bp.route("/api/services", methods=["POST"])
@jwt_required()
def create_service():
    user_id = get_jwt_identity()
    data = request.get_json(silent=True) or {}
    name = data.get("name")
    internal_port = data.get("internal_port")

    if not name or not internal_port:
        return jsonify({"error": "name and internal_port are required"}), 400

    service = Service(owner_id=user_id, name=name, internal_port=internal_port)
    db.session.add(service)
    db.session.commit()

    return jsonify(service.to_dict()), 201


@main_bp.route("/api/services/<int:service_id>", methods=["DELETE"])
@jwt_required()
def delete_service(service_id):
    user_id = get_jwt_identity()
    service = Service.query.filter_by(id=service_id, owner_id=user_id).first()
    if not service:
        return jsonify({"error": "not found"}), 404

    db.session.delete(service)
    db.session.commit()
    return jsonify({"deleted": service_id}), 200
