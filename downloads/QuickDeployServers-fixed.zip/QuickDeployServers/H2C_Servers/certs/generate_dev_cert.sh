#!/usr/bin/env bash
# Generates a self-signed TLS cert for local development only.
# For production, use Let's Encrypt/Certbot or a real CA-issued certificate.
set -euo pipefail

mkdir -p "$(dirname "$0")"
cd "$(dirname "$0")"

openssl req -x509 -nodes -newkey rsa:2048 \
  -keyout your_private.key \
  -out your_certificate.crt \
  -days 365 \
  -subj "/CN=localhost"

openssl dhparam -out dhparam.pem 2048

echo "Generated self-signed cert in $(pwd). Do not use these in production."
