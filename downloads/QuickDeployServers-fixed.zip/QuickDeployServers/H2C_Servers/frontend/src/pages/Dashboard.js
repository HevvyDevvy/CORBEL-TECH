import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import api from "../api";

function Dashboard() {
  const [services, setServices] = useState([]);
  const [name, setName] = useState("");
  const [port, setPort] = useState("");
  const [error, setError] = useState("");
  const navigate = useNavigate();

  const load = async () => {
    try {
      const res = await api.get("/api/services");
      setServices(res.data);
    } catch (err) {
      if (err.response?.status === 401) {
        localStorage.removeItem("h2c_token");
        navigate("/login");
      } else {
        setError("Failed to load services");
      }
    }
  };

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleCreate = async (e) => {
    e.preventDefault();
    setError("");
    try {
      await api.post("/api/services", { name, internal_port: Number(port) });
      setName("");
      setPort("");
      load();
    } catch (err) {
      setError(err.response?.data?.error || "Failed to create service");
    }
  };

  const handleDelete = async (id) => {
    await api.delete(`/api/services/${id}`);
    load();
  };

  const handleLogout = () => {
    localStorage.removeItem("h2c_token");
    navigate("/login");
  };

  return (
    <div style={{ maxWidth: 640, margin: "2rem auto", fontFamily: "sans-serif" }}>
      <div style={{ display: "flex", justifyContent: "space-between" }}>
        <h1>Your hosted services</h1>
        <button onClick={handleLogout}>Log out</button>
      </div>

      <form onSubmit={handleCreate} style={{ marginBottom: 16 }}>
        <input
          placeholder="Service name"
          value={name}
          onChange={(e) => setName(e.target.value)}
        />
        <input
          placeholder="Internal port"
          value={port}
          onChange={(e) => setPort(e.target.value)}
          style={{ marginLeft: 8, width: 120 }}
        />
        <button type="submit" style={{ marginLeft: 8 }}>
          Add
        </button>
      </form>
      {error && <p style={{ color: "red" }}>{error}</p>}

      <table width="100%" cellPadding={6}>
        <thead>
          <tr>
            <th align="left">Name</th>
            <th align="left">Port</th>
            <th align="left">Status</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          {services.map((s) => (
            <tr key={s.id}>
              <td>{s.name}</td>
              <td>{s.internal_port}</td>
              <td>{s.status}</td>
              <td>
                <button onClick={() => handleDelete(s.id)}>Remove</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default Dashboard;
