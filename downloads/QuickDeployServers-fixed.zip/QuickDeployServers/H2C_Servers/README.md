# Home2Cloud (H2C)

Self-hosted cloud starter: Flask API with JWT auth and SQLAlchemy, a React
dashboard for managing hosted services, and nginx for TLS termination and
reverse proxying — meant to run on a home network with the option to move
to a cloud VM later.

## Run with Docker Compose

```bash
# 1. Generate a local dev TLS cert (or drop in real certs from Certbot/your CA)
./certs/generate_dev_cert.sh

# 2. Start everything
docker compose up --build
```

Visit https://localhost (self-signed cert — your browser will warn, that's
expected in dev).

## Architecture

```
nginx (TLS termination, :80 → :443 redirect)
  └── frontend (React SPA, served by nginx, proxies /api/* internally)
        └── backend (Flask, JWT auth, SQLAlchemy, SQLite by default)
```

## Backend API

- `POST /api/auth/register` — `{email, password}`
- `POST /api/auth/login` — `{email, password}` → `{access_token}`
- `GET /api/services` — list your hosted services (requires `Authorization: Bearer <token>`)
- `POST /api/services` — `{name, internal_port}`
- `DELETE /api/services/<id>`

## Configuration

Set via environment variables (see `docker-compose.yml`):

- `SECRET_KEY`, `JWT_SECRET_KEY` — change these for anything beyond local dev
- `DATABASE_URL` — defaults to local SQLite; point at Postgres/MySQL to scale

## Run without Docker

```bash
# Backend
cd backend
pip install -r requirements.txt
python wsgi.py

# Frontend
cd frontend
npm install
npm start
```
