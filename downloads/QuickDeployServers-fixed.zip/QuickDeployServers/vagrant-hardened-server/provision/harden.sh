#!/usr/bin/env bash
set -euo pipefail

apt-get update
apt-get upgrade -y
apt-get install -y ufw fail2ban unattended-upgrades

# Firewall: deny by default, allow SSH only
ufw default deny incoming
ufw default allow outgoing
ufw allow OpenSSH
ufw --force enable

# Fail2ban for SSH brute-force protection
systemctl enable fail2ban
systemctl start fail2ban

# Automatic security updates
dpkg-reconfigure -f noninteractive unattended-upgrades

# Disable root SSH login and password auth (key-based only)
sed -i 's/^#\?PermitRootLogin.*/PermitRootLogin no/' /etc/ssh/sshd_config
sed -i 's/^#\?PasswordAuthentication.*/PasswordAuthentication no/' /etc/ssh/sshd_config
systemctl restart sshd

echo "Hardening complete: ufw enabled (SSH only), fail2ban running, unattended-upgrades configured, password SSH auth disabled."
