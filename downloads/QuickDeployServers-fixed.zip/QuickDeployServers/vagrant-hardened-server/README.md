# vagrant-hardened-server — quick deploy

One command gets you a local VM with baseline server hardening already
applied — the Vagrant/VirtualBox counterpart to the cloud quick-deploys,
for when you want a real (if local) server rather than a container.

## Run

```bash
vagrant up
vagrant ssh
```

## What's applied (`provision/harden.sh`)

- System fully updated
- `ufw` firewall: deny all incoming except SSH
- `fail2ban` running against SSH brute-force attempts
- `unattended-upgrades` for automatic security patches
- SSH hardened: no root login, no password auth (key-based only —
  make sure your Vagrant box's default insecure keypair is replaced
  with your own before relying on this beyond local testing)

## Customize

Add your own provisioning steps to `provision/harden.sh`, or add a
second `config.vm.provision "shell", inline: "..."` block in the
`Vagrantfile` for app-specific setup.
