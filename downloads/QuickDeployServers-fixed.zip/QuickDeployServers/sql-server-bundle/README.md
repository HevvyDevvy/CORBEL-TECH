# SQL server bundle — quick deploy

A local/on-prem MySQL + PostgreSQL pair with Adminer as a shared web UI
— the on-prem counterpart to the cloud-managed DB repos (Maria_GCP,
PostgreSQL_Azure_server, MySql_AWS-RDS_Secure_Server) for when you just
need a database on a box, not a managed cloud instance.

## Run

```bash
cp .env.example .env   # set real passwords
docker compose up -d
```

- MySQL: `localhost:3306`
- PostgreSQL: `localhost:5432`
- Adminer (web UI for both): http://localhost:8081

## Note on security

This is convenient for local dev/staging, not hardened for direct
internet exposure — don't publish these ports publicly. For an
internet-facing setup, put it behind the nginx TLS proxy from
`H2C_Servers` and restrict the DB ports to an internal Docker network
only (drop the `ports:` mappings on `mysql`/`postgres` once your app
containers are on the same network).
