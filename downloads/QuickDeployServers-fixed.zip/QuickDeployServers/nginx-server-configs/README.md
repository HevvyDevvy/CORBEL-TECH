# nginx_server_conf-files

nginx server-block configs for secure servers.

- `nginx_base_file.conf` — stock nginx.conf-style base config (unmodified default, HTTP only)
- `nginx.conf` — HTTPS server block, reverse-proxying to a frontend (`:8080`) and a `/blockchain/` backend (`:8000`)
- `nginx_sec.conf` — HTTPS server block with HSTS, hardened TLS ciphers/protocols, security headers, rate-limit/access-control examples (commented), logging
- `nginx_sec_conf.conf` — full base config (events/http blocks) combining the default HTTP server with the hardened HTTPS server from `nginx_sec.conf`
- `nginx_sec_https.conf` — same HTTPS proxy setup as `nginx.conf`, standalone

## Use

Drop the one that matches your setup into `/etc/nginx/sites-available/`
(or `/etc/nginx/conf.d/`), update `server_name` and the `ssl_certificate`
paths, then:

```bash
sudo nginx -t   # verify syntax
sudo systemctl reload nginx
```

`nginx_sec_conf.conf` and `nginx_base_file.conf` are full standalone
configs (they include their own `events {}`/`http {}` blocks) — use one
of those as `/etc/nginx/nginx.conf` directly. The others are server-block
fragments meant to be included inside an existing `http {}` block.

Note: previous versions of this repo had an unrelated Kivy/Android
`buildozer.spec` (Android packaging config for a chess game) mixed in
here by mistake — removed, it belonged to a different project.
