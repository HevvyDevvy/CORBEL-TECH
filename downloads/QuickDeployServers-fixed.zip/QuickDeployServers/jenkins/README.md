# Jenkins — quick deploy

A ready-to-run, security-configured Jenkins instance: no setup wizard,
no anonymous access, one admin user defined via Configuration-as-Code
(no clicking through the first-run flow).

## Run

```bash
cp .env.example .env   # set a real JENKINS_ADMIN_PASSWORD
docker compose up --build
```

Visit http://localhost:8080 and log in with the credentials from `.env`.

## What's pre-configured

- Setup wizard skipped entirely
- Local security realm with a single admin user (no signup, no anonymous read)
- Global matrix authorization — only the admin user has any permissions by default; add more users/permissions in `casc.yaml`
- Plugins baked into the image at build time (`plugins.txt`): Configuration as Code, Git, Pipeline (workflow-aggregator), Matrix Auth, Credentials Binding

## Customize

Edit `casc.yaml` to add credentials, seed jobs, or additional users —
JCasC re-applies it on every container start.
