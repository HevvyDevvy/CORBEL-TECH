# MySql_AWS-RDS_Secure_Server

Terraform to provision a hardened AWS RDS MySQL instance — private
subnets only, security-group-scoped access, KMS-encrypted storage,
IAM database auth enabled, Multi-AZ, CloudWatch log exports — plus a
Flask service that proves the connection is actually TLS-enforced.

## Provision

```bash
cd terraform
cp terraform.tfvars.example terraform.tfvars   # fill in app_security_group_id, etc.
export TF_VAR_master_password="a-strong-password"
terraform init
terraform plan
terraform apply
```

`app_security_group_id` must be the security group of whatever app tier
(e.g. an EC2/ECS app) needs to reach the DB — RDS is not exposed publicly
and won't accept connections from anywhere else.

## Run the connectivity check

```bash
# Download AWS's RDS CA bundle first:
curl -o rds-combined-ca-bundle.pem https://truststore.pki.rds.amazonaws.com/global/global-bundle.pem

cd app
pip install -r requirements.txt
export DB_HOST=$(terraform -chdir=../terraform output -raw db_endpoint)
export DB_NAME=mydatabase
export DB_USER=admin
export DB_PASSWORD=<your password>
export RDS_CA_BUNDLE=../rds-combined-ca-bundle.pem
python app.py
```

`curl http://localhost:8080/db-check` returns the server version and the
negotiated `ssl_cipher` — a non-empty cipher confirms the connection is
actually encrypted, not just configured to be.
