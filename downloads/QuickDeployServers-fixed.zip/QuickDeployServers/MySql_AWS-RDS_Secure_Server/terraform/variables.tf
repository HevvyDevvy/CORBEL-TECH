variable "region" {
  type    = string
  default = "us-east-1"
}

variable "db_identifier" {
  type    = string
  default = "mydbinstance"
}

variable "instance_class" {
  type    = string
  default = "db.t3.micro"
}

variable "multi_az" {
  type    = bool
  default = true
}

variable "master_username" {
  type    = string
  default = "admin"
}

variable "master_password" {
  description = "Pass via TF_VAR_master_password, never commit it."
  type        = string
  sensitive   = true
}

variable "app_security_group_id" {
  description = "Security group ID of the application tier allowed to reach MySQL on 3306"
  type        = string
}
