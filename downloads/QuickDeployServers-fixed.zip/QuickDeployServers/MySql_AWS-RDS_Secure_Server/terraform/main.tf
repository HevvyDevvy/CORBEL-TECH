terraform {
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.0"
    }
  }
}

provider "aws" {
  region = var.region
}

resource "aws_vpc" "main" {
  cidr_block = "10.0.0.0/16"
  tags       = { Name = "${var.db_identifier}-vpc" }
}

resource "aws_subnet" "private_a" {
  vpc_id            = aws_vpc.main.id
  cidr_block        = "10.0.1.0/24"
  availability_zone = "${var.region}a"
  tags              = { Name = "${var.db_identifier}-subnet-a" }
}

resource "aws_subnet" "private_b" {
  vpc_id            = aws_vpc.main.id
  cidr_block        = "10.0.2.0/24"
  availability_zone = "${var.region}b"
  tags              = { Name = "${var.db_identifier}-subnet-b" }
}

resource "aws_db_subnet_group" "db_subnets" {
  name       = "${var.db_identifier}-subnet-group"
  subnet_ids = [aws_subnet.private_a.id, aws_subnet.private_b.id]
}

resource "aws_security_group" "mysql_sg" {
  name        = "${var.db_identifier}-sg"
  description = "Allow MySQL only from application security group"
  vpc_id      = aws_vpc.main.id

  ingress {
    description     = "MySQL from app tier"
    from_port       = 3306
    to_port         = 3306
    protocol        = "tcp"
    security_groups = [var.app_security_group_id]
  }

  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }
}

resource "aws_kms_key" "rds_key" {
  description = "KMS key for ${var.db_identifier} RDS encryption"
}

resource "aws_db_instance" "mysql" {
  identifier                  = var.db_identifier
  engine                      = "mysql"
  engine_version              = "8.0"
  instance_class              = var.instance_class
  allocated_storage           = 20
  storage_encrypted           = true
  kms_key_id                  = aws_kms_key.rds_key.arn
  username                    = var.master_username
  password                    = var.master_password
  db_subnet_group_name        = aws_db_subnet_group.db_subnets.name
  vpc_security_group_ids      = [aws_security_group.mysql_sg.id]
  multi_az                    = var.multi_az
  backup_retention_period     = 7
  publicly_accessible         = false
  iam_database_authentication_enabled = true
  deletion_protection         = true
  skip_final_snapshot         = false
  final_snapshot_identifier   = "${var.db_identifier}-final-snapshot"

  enabled_cloudwatch_logs_exports = ["error", "general", "slowquery"]
}
