"""Small Flask service verifying a TLS-enforced connection to the RDS
MySQL instance, using AWS's RDS CA bundle to validate the server cert."""
import os

from flask import Flask, jsonify
import pymysql

app = Flask(__name__)


def get_connection():
    return pymysql.connect(
        host=os.environ["DB_HOST"],
        user=os.environ["DB_USER"],
        password=os.environ["DB_PASSWORD"],
        database=os.environ["DB_NAME"],
        ssl={"ca": os.environ.get("RDS_CA_BUNDLE", "/certs/rds-combined-ca-bundle.pem")},
        connect_timeout=5,
    )


@app.route("/health", methods=["GET"])
def health():
    return jsonify({"status": "ok"}), 200


@app.route("/db-check", methods=["GET"])
def db_check():
    try:
        conn = get_connection()
        with conn.cursor() as cur:
            cur.execute("SELECT VERSION()")
            version = cur.fetchone()[0]
            cur.execute("SHOW STATUS LIKE 'Ssl_cipher'")
            ssl_cipher = cur.fetchone()
        conn.close()
        return jsonify({
            "connected": True,
            "server_version": version,
            "ssl_cipher": ssl_cipher[1] if ssl_cipher else None,
        }), 200
    except Exception as e:
        return jsonify({"connected": False, "error": str(e)}), 500


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8080)
