# Maria_GCP

Terraform to provision a secure Google Cloud SQL instance (MySQL-compatible —
see note in `terraform/main.tf` re: MariaDB), plus a small Flask service
that proves connectivity over an enforced SSL connection.

**Note:** Cloud SQL does not offer a native MariaDB engine; this uses
`MYSQL_5_7` as the closest managed, wire-compatible option. If you need
actual MariaDB (not just compatibility), run it on Compute Engine or GKE
instead of Cloud SQL.

## Provision the database

```bash
cd terraform
cp terraform.tfvars.example terraform.tfvars   # fill in your project_id, vpc_self_link
export TF_VAR_db_password="a-strong-password"
terraform init
terraform plan
terraform apply
```

## Run the connectivity check

```bash
cd app
pip install -r requirements.txt
export DB_HOST=<private IP from terraform output>
export DB_USER=myuser
export DB_PASSWORD=<your password>
export DB_NAME=mydatabase
export DB_SSL_CA=/path/to/server-ca.pem
export DB_SSL_CERT=/path/to/client-cert.pem
export DB_SSL_KEY=/path/to/client-key.pem
python app.py
```

Then `curl http://localhost:8080/db-check` — a `connected: true` response
with the server version confirms the SSL-enforced connection works.

Download the SSL certs for your instance from the Cloud Console or via
`gcloud sql instances describe <instance-name>`.
