"""Small Flask service that verifies connectivity to the provisioned
Cloud SQL (MariaDB/MySQL-compatible) instance over an enforced SSL
connection. Meant as a working proof-of-connectivity, not a full app.
"""
import os

from flask import Flask, jsonify
import pymysql

app = Flask(__name__)

DB_CONFIG = {
    "host": os.environ["DB_HOST"],
    "user": os.environ["DB_USER"],
    "password": os.environ["DB_PASSWORD"],
    "database": os.environ["DB_NAME"],
    "ssl": {
        "ca": os.environ.get("DB_SSL_CA", "/certs/ca-cert.pem"),
        "cert": os.environ.get("DB_SSL_CERT", "/certs/client-cert.pem"),
        "key": os.environ.get("DB_SSL_KEY", "/certs/client-key.pem"),
    },
}


@app.route("/health", methods=["GET"])
def health():
    return jsonify({"status": "ok"}), 200


@app.route("/db-check", methods=["GET"])
def db_check():
    try:
        conn = pymysql.connect(**DB_CONFIG, connect_timeout=5)
        with conn.cursor() as cur:
            cur.execute("SELECT VERSION()")
            version = cur.fetchone()[0]
        conn.close()
        return jsonify({"connected": True, "server_version": version}), 200
    except Exception as e:
        return jsonify({"connected": False, "error": str(e)}), 500


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8080)
