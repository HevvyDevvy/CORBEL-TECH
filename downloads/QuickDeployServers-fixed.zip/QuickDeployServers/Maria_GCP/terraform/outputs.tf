output "instance_connection_name" {
  value = google_sql_database_instance.mariadb.connection_name
}

output "private_ip_address" {
  value = google_sql_database_instance.mariadb.private_ip_address
}

output "database_name" {
  value = google_sql_database.app_db.name
}
