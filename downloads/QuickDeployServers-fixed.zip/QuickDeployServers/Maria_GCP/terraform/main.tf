terraform {
  required_providers {
    google = {
      source  = "hashicorp/google"
      version = "~> 5.0"
    }
  }
}

provider "google" {
  project = var.project_id
  region  = var.region
}

resource "google_sql_database_instance" "mariadb" {
  name             = var.instance_name
  database_version = "MYSQL_5_7" # Cloud SQL has no native MariaDB engine as of
                                  # this writing; MySQL-compatible is the closest
                                  # managed equivalent. Swap for a self-managed
                                  # MariaDB on Compute Engine if MariaDB itself
                                  # (not just wire-compatibility) is required.
  region           = var.region

  settings {
    tier              = var.tier
    availability_type = var.high_availability ? "REGIONAL" : "ZONAL"

    backup_configuration {
      enabled            = true
      start_time         = "03:00"
      binary_log_enabled = true
    }

    ip_configuration {
      ipv4_enabled = false
      dynamic "authorized_networks" {
        for_each = var.authorized_networks
        content {
          name  = authorized_networks.value.name
          value = authorized_networks.value.cidr
        }
      }
      private_network = var.vpc_self_link
    }

    database_flags {
      name  = "log_min_duration_statement"
      value = "0"
    }
  }

  deletion_protection = true
}

resource "google_sql_database" "app_db" {
  name     = var.database_name
  instance = google_sql_database_instance.mariadb.name
}

resource "google_sql_user" "app_user" {
  name     = var.db_user
  instance = google_sql_database_instance.mariadb.name
  password = var.db_password
}

resource "google_kms_key_ring" "db_keyring" {
  count    = var.enable_cmek ? 1 : 0
  name     = "${var.instance_name}-keyring"
  location = var.region
}

resource "google_kms_crypto_key" "db_key" {
  count    = var.enable_cmek ? 1 : 0
  name     = "${var.instance_name}-key"
  key_ring = google_kms_key_ring.db_keyring[0].id
  purpose  = "ENCRYPT_DECRYPT"
}
