variable "project_id" {
  description = "GCP project ID"
  type        = string
}

variable "region" {
  description = "GCP region"
  type        = string
  default     = "us-central1"
}

variable "instance_name" {
  description = "Cloud SQL instance name"
  type        = string
  default     = "my-mariadb-instance"
}

variable "tier" {
  description = "Machine tier for the instance"
  type        = string
  default     = "db-f1-micro"
}

variable "high_availability" {
  description = "Whether to run the instance as REGIONAL (HA) vs ZONAL"
  type        = bool
  default     = false
}

variable "database_name" {
  type    = string
  default = "mydatabase"
}

variable "db_user" {
  type    = string
  default = "myuser"
}

variable "db_password" {
  description = "Password for db_user. Pass via TF_VAR_db_password, never commit it."
  type        = string
  sensitive   = true
}

variable "vpc_self_link" {
  description = "Self link of the VPC to attach via private services access"
  type        = string
}

variable "authorized_networks" {
  description = "CIDR ranges allowed to connect (only used if private_network is not sufficient)"
  type = list(object({
    name = string
    cidr = string
  }))
  default = []
}

variable "enable_cmek" {
  description = "Whether to create a KMS key ring/key for customer-managed encryption"
  type        = bool
  default     = false
}
