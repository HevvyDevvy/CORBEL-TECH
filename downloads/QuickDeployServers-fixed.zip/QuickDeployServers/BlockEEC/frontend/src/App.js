import React, { useState } from "react";
import axios from "axios";

function App() {
  const [hash, setHash] = useState("");
  const [privateKey, setPrivateKey] = useState("");
  const [result, setResult] = useState("");
  const [loading, setLoading] = useState(false);

  const handleHashSubmit = async () => {
    setLoading(true);
    try {
      const response = await axios.post("/predict_blockchain", { hash });
      setResult(`Blockchain hash result: ${response.data.result}`);
    } catch (error) {
      setResult("Error: " + (error.response?.data?.error || error.message));
    } finally {
      setLoading(false);
    }
  };

  const handleECCSubmit = async () => {
    setLoading(true);
    try {
      const response = await axios.post("/predict_ecc", {
        private_key: privateKey,
      });
      setResult(`ECC key result: ${response.data.result}`);
    } catch (error) {
      setResult("Error: " + (error.response?.data?.error || error.message));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{ maxWidth: 480, margin: "2rem auto", fontFamily: "sans-serif" }}>
      <h1>Cryptographic Vulnerability Predictor</h1>

      <h2>Blockchain Hash Vulnerability</h2>
      <input
        type="text"
        placeholder="Enter blockchain hash (hex)"
        value={hash}
        onChange={(e) => setHash(e.target.value)}
        style={{ width: "100%", marginBottom: 8 }}
      />
      <button onClick={handleHashSubmit} disabled={loading || !hash}>
        Check Hash
      </button>

      <h2>Elliptic Curve Key Vulnerability</h2>
      <input
        type="text"
        placeholder="Enter ECC private key (hex)"
        value={privateKey}
        onChange={(e) => setPrivateKey(e.target.value)}
        style={{ width: "100%", marginBottom: 8 }}
      />
      <button onClick={handleECCSubmit} disabled={loading || !privateKey}>
        Check ECC Key
      </button>

      <h3>Prediction Result</h3>
      <div>{loading ? "Checking..." : result}</div>
    </div>
  );
}

export default App;
