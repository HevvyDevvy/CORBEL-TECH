# BlockEEC — Cryptographic Vulnerability Predictor

A small full-stack demo: a Flask API serves predictions from a RandomForest
model trained on statistical features of blockchain hashes and ECC private
keys (given as hex strings), with a React frontend to query it.

**Note on scope:** the "vulnerability" label is a synthetic demo target
(see `scripts/generate_data.py`) based on superficial string statistics —
this is a scaffold to build real cryptographic weakness detection on top
of, not a validated security tool as-is.

## Run with Docker Compose

```bash
docker compose up --build
```

- Frontend: http://localhost:3000
- Backend API: http://localhost:5000

On first start, the backend container generates synthetic training data
and trains the model automatically — no manual steps needed.

## Run locally without Docker

```bash
# Backend
cd backend
pip install -r requirements.txt
python ../scripts/generate_data.py
python ../scripts/train_model.py
python app.py

# Frontend (separate terminal)
cd frontend
npm install
npm start
```

## API

- `POST /predict_blockchain` — body `{"hash": "<hex string>"}`
- `POST /predict_ecc` — body `{"private_key": "<hex string>"}`
- `GET /health`

## Project layout

```
BlockEEC/
├── backend/        Flask API, feature extraction, model loading
├── frontend/       React UI
├── scripts/        generate_data.py, train_model.py
├── data/           generated training CSV (created at runtime)
└── docker-compose.yml
```
