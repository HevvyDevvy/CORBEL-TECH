"""Model loading and prediction helpers."""
import os
import joblib

MODEL_PATH = os.path.join(os.path.dirname(__file__), "model_v2.pkl")

_model_cache = None


def load_model():
    """Load the trained model from disk, caching it in memory.

    Raises FileNotFoundError with a clear message if the model hasn't
    been trained yet (run scripts/train_model.py first).
    """
    global _model_cache
    if _model_cache is not None:
        return _model_cache
    if not os.path.exists(MODEL_PATH):
        raise FileNotFoundError(
            f"No trained model found at {MODEL_PATH}. "
            "Run `python scripts/generate_data.py && python scripts/train_model.py` first."
        )
    _model_cache = joblib.load(MODEL_PATH)
    return _model_cache


def predict_vulnerability(model, features):
    """Make a vulnerability prediction using the trained model."""
    prediction = model.predict([features])
    return int(prediction[0])
