from flask import Flask, request, jsonify
from flask_cors import CORS

from feature_extractor import analyze_hash, analyze_ecc_key
from model import load_model, predict_vulnerability

app = Flask(__name__)
CORS(app)


@app.route("/health", methods=["GET"])
def health():
    return jsonify({"status": "ok"}), 200


@app.route("/predict_blockchain", methods=["POST"])
def predict_blockchain():
    """Predict vulnerability for blockchain hashes."""
    data = request.get_json(silent=True) or {}
    blockchain_hash = data.get("hash")

    if not blockchain_hash:
        return jsonify({"error": "Hash is required"}), 400

    try:
        features = analyze_hash(blockchain_hash)
        model = load_model()
        result = predict_vulnerability(model, features)
        return jsonify({"result": result}), 200
    except FileNotFoundError as e:
        return jsonify({"error": str(e)}), 503
    except ValueError as e:
        return jsonify({"error": str(e)}), 400


@app.route("/predict_ecc", methods=["POST"])
def predict_ecc():
    """Predict vulnerability for ECC keys (hex-encoded scalar)."""
    data = request.get_json(silent=True) or {}
    private_key = data.get("private_key")

    if not private_key:
        return jsonify({"error": "private_key is required"}), 400

    try:
        features = analyze_ecc_key(private_key)
        model = load_model()
        result = predict_vulnerability(model, features)
        return jsonify({"result": result}), 200
    except FileNotFoundError as e:
        return jsonify({"error": str(e)}), 503
    except ValueError as e:
        return jsonify({"error": str(e)}), 400


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=False)
