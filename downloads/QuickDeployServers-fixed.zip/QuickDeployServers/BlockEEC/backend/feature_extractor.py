"""Feature extraction for blockchain hashes and ECC private keys.

These are lightweight, explainable statistical features (not a claim of
cryptographic rigor) used to feed the demo RandomForest classifier.
"""
import re

HEX_RE = re.compile(r"^[0-9a-fA-F]+$")


def _validate_hex(value: str, field_name: str) -> None:
    if not value or not isinstance(value, str):
        raise ValueError(f"{field_name} must be a non-empty string")
    if not HEX_RE.match(value):
        raise ValueError(f"{field_name} must be a hexadecimal string")


def analyze_hash(blockchain_hash: str):
    """Extract features from a blockchain hash string."""
    _validate_hex(blockchain_hash, "hash")
    length = len(blockchain_hash)
    zero_count = blockchain_hash.count("0")
    leading_zeros = len(blockchain_hash) - len(blockchain_hash.lstrip("0"))
    unique_chars = len(set(blockchain_hash.lower()))
    return [length, zero_count, leading_zeros, unique_chars]


def analyze_ecc_key(private_key: str):
    """Extract features from an ECC private key given as a hex string.

    Note: this accepts a raw hex-encoded scalar for demo purposes, not a
    PEM-encoded key. A production system should never accept raw private
    key material over an API.
    """
    _validate_hex(private_key, "private_key")
    length = len(private_key)
    f_count = private_key.lower().count("f")
    leading_zeros = len(private_key) - len(private_key.lstrip("0"))
    unique_chars = len(set(private_key.lower()))
    return [length, f_count, leading_zeros, unique_chars]


FEATURE_COLUMNS = ["feature1", "feature2", "feature3", "feature4"]
