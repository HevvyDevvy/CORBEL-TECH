"""Train and save the demo vulnerability-prediction model."""
import os

import joblib
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split

DATA_PATH = os.path.join(os.path.dirname(__file__), "..", "data", "known_vulnerabilities.csv")
MODEL_PATH = os.path.join(os.path.dirname(__file__), "..", "backend", "model_v2.pkl")

if __name__ == "__main__":
    if not os.path.exists(DATA_PATH):
        raise SystemExit(
            f"No training data found at {DATA_PATH}. Run generate_data.py first."
        )

    data = pd.read_csv(DATA_PATH)
    X = data.drop("vulnerable", axis=1)
    y = data["vulnerable"]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42
    )

    model = RandomForestClassifier(n_estimators=100, random_state=42)
    model.fit(X_train, y_train)

    accuracy = model.score(X_test, y_test)
    print(f"Held-out accuracy: {accuracy:.3f}")

    os.makedirs(os.path.dirname(MODEL_PATH), exist_ok=True)
    joblib.dump(model, MODEL_PATH)
    print(f"Saved model to {MODEL_PATH}")
