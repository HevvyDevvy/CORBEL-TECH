"""Generate synthetic training data for the demo vulnerability model."""
import os
import random
import string

import pandas as pd

OUTPUT_PATH = os.path.join(os.path.dirname(__file__), "..", "data", "known_vulnerabilities.csv")


def generate_synthetic_data(n: int) -> pd.DataFrame:
    rows = []
    for _ in range(n):
        blockchain_hash = "".join(random.choices(string.hexdigits.lower()[:16], k=64))
        length = len(blockchain_hash)
        zero_count = blockchain_hash.count("0")
        leading_zeros = len(blockchain_hash) - len(blockchain_hash.lstrip("0"))
        unique_chars = len(set(blockchain_hash))
        # Toy "ground truth": flag as vulnerable when there are unusually
        # many leading zeros or low character diversity -- purely for
        # demo purposes, not a real vulnerability heuristic.
        vulnerable = int(leading_zeros >= 3 or unique_chars <= 6)
        rows.append([length, zero_count, leading_zeros, unique_chars, vulnerable])

    return pd.DataFrame(
        rows, columns=["feature1", "feature2", "feature3", "feature4", "vulnerable"]
    )


if __name__ == "__main__":
    os.makedirs(os.path.dirname(OUTPUT_PATH), exist_ok=True)
    df = generate_synthetic_data(1000)
    df.to_csv(OUTPUT_PATH, index=False)
    print(f"Wrote {len(df)} rows to {OUTPUT_PATH}")
