# Quick Deploy Servers

Every real, deployable server product built so far, each as its own
self-contained folder. Real secrets are already generated into `.env`
files (not just `.env.example`) wherever that's possible — `docker
compose up --build` runs immediately, no manual editing required.

Rotate the generated passwords before using any of these beyond local
testing/demo — they're strong random values, but they're sitting in
plain text in this download.

## Products

| Folder | What it is | Runs OTB with just `docker compose up`? |
|---|---|---|
| `BlockEEC` | Flask+React crypto vulnerability predictor demo | Yes |
| `H2C_Servers` | Self-hosted cloud starter — Flask+JWT+React+nginx TLS | Yes (self-signed dev cert auto-generated) |
| `jenkins` | CI server, no setup wizard, admin pre-configured | Yes |
| `gitlab` | GitLab CE, signup disabled, root password pre-set | Yes (first boot takes a few minutes) |
| `sql-server-bundle` | MySQL + PostgreSQL + Adminer | Yes |
| `oracle-db` | Oracle DB Free + connectivity check | One prereq: `docker login container-registry.oracle.com` (Oracle's own licensing gate, not something a container can bypass) |
| `k3s-local` | Single-node real Kubernetes cluster | Yes |
| `smtp-server` | Postfix+Dovecot+OpenDKIM, TLS-enforced, no open relay | Yes for local testing; needs a DNS TXT record added (printed on first boot) before sending real mail anywhere |
| `vagrant-hardened-server` | Hardened Ubuntu VM template | One prereq: Vagrant + VirtualBox installed on your machine — this one provisions a VM, not a container, so it can't run inside `docker compose` |
| `nginx-server-configs` | Real nginx server-block configs (HTTPS, reverse proxy, hardened variants) | These are configs for an nginx install, not a standalone deployable service — drop into `/etc/nginx/` on any box running nginx |
| `Maria_GCP` | Terraform for a secure Cloud SQL (MySQL-compatible) instance | Needs your own GCP project ID + `TF_VAR_db_password` — provisioning a cloud resource always needs your account, that's not something any download can pre-fill |
| `PostgreSQL_Azure_server` | Terraform for a secure Azure PostgreSQL Flexible Server | Same as above — needs your own Azure subscription |
| `MySql_AWS-RDS_Secure_Server` | Terraform for a secure AWS RDS MySQL instance | Same as above — needs your own AWS account |

The first eight run with zero manual setup. The last three provision
real cloud infrastructure, which structurally requires your own cloud
account credentials — no package can ship those for you.
