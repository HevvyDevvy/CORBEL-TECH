#!/usr/bin/env bash
set -euo pipefail

: "${MAIL_DOMAIN:?Set MAIL_DOMAIN in .env}"
: "${DKIM_SELECTOR:=mail}"
: "${SMTP_USER:?Set SMTP_USER in .env}"
: "${SMTP_PASSWORD:?Set SMTP_PASSWORD in .env}"

# --- Render config templates ---
export MAIL_DOMAIN DKIM_SELECTOR
envsubst '${MAIL_DOMAIN} ${DKIM_SELECTOR}' < /etc/postfix/main.cf.template > /etc/postfix/main.cf
envsubst '${MAIL_DOMAIN} ${DKIM_SELECTOR}' < /etc/opendkim.conf.template > /etc/opendkim.conf

# --- TLS cert: use mounted real certs if present, else self-sign for local testing ---
mkdir -p /etc/postfix/certs
if [ ! -f /etc/postfix/certs/fullchain.pem ]; then
    echo "[entrypoint] No TLS cert mounted -- generating a self-signed one for local testing."
    openssl req -x509 -nodes -newkey rsa:2048 \
        -keyout /etc/postfix/certs/privkey.pem \
        -out /etc/postfix/certs/fullchain.pem \
        -days 365 -subj "/CN=mail.${MAIL_DOMAIN}"
fi

# --- DKIM key: generate on first run, print the DNS record every time ---
mkdir -p /etc/opendkim/keys
if [ ! -f "/etc/opendkim/keys/${DKIM_SELECTOR}.private" ]; then
    echo "[entrypoint] Generating DKIM keypair for selector '${DKIM_SELECTOR}'."
    opendkim-genkey -D /etc/opendkim/keys -d "${MAIL_DOMAIN}" -s "${DKIM_SELECTOR}"
    mv "/etc/opendkim/keys/${DKIM_SELECTOR}.private" "/etc/opendkim/keys/${DKIM_SELECTOR}.private" 2>/dev/null || true
fi
chown -R opendkim:opendkim /etc/opendkim/keys
echo "=============================================================="
echo "Add this DNS TXT record before sending mail (required for DKIM"
echo "to pass at the receiving end):"
echo
cat "/etc/opendkim/keys/${DKIM_SELECTOR}.txt"
echo "=============================================================="

# --- Dovecot user (SASL auth for Postfix submission) ---
HASH=$(doveadm pw -s SHA512-CRYPT -p "${SMTP_PASSWORD}")
echo "${SMTP_USER}@${MAIL_DOMAIN}:${HASH}" > /etc/dovecot/users
chmod 600 /etc/dovecot/users

# --- Permissions Postfix expects ---
postfix set-permissions 2>/dev/null || true
mkdir -p /var/spool/postfix/private
chown postfix:postfix /var/spool/postfix/private

exec /usr/bin/supervisord -c /etc/supervisor/conf.d/supervisord.conf
