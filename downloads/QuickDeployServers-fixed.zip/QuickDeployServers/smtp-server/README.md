# smtp-server — quick deploy

A real, working outbound-mail SMTP server: Postfix (TLS-enforced
submission on 587, no open relay) + Dovecot (SASL auth) + OpenDKIM
(signs outbound mail), all wired together in one container via
supervisord.

## Run

```bash
cp .env.example .env   # set MAIL_DOMAIN, SMTP_USER, SMTP_PASSWORD
docker compose up --build
```

On first start it prints a DKIM DNS TXT record — **add it to your
domain's DNS before sending real mail**, or receiving servers will
mark your mail as unauthenticated/spam. It also self-signs a TLS cert
for local testing; drop your real `fullchain.pem`/`privkey.pem` into
`./certs/` for production use (e.g. from Let's Encrypt/Certbot).

## Send a test message

```bash
swaks --to test@example.com --from noreply@yourdomain.com \
  --server localhost:587 --auth LOGIN \
  --auth-user noreply@yourdomain.com --auth-password <SMTP_PASSWORD> \
  --tls
```

(`swaks` is a standard SMTP testing tool — `apt install swaks` or
similar.)

## Security posture

- **No open relay**: `smtpd_relay_restrictions` only permits mail from `mynetworks` or SASL-authenticated senders — an anonymous sender from the internet cannot use this to relay mail anywhere.
- **Submission (587) enforces TLS + auth**: `smtpd_tls_security_level=encrypt` and `smtpd_client_restrictions=permit_sasl_authenticated,reject` on that port.
- **DKIM-signs everything outbound** via the OpenDKIM milter.
- You still need SPF and DMARC DNS records pointing at this server's IP/domain for mail to land in inboxes reliably — those are DNS-side, not something a container can set for you.

## Not included

IMAP/receiving mailboxes — this is an outbound/relay setup only (matching "automated secure transmission," not a full mailbox server). Add `dovecot-imapd` and mailbox storage config if you need inbound delivery too.
