# k3s-local — quick deploy

A real single-node Kubernetes cluster (k3s) you can be running against
in under a minute, for local testing before you commit to a managed
cluster (EKS/GKE/AKS) or the Kubernautes production setup.

## Run

```bash
cp .env.example .env   # set K3S_TOKEN to something real, not the default
docker compose up -d
```

A kubeconfig is written to `./kubeconfig/kubeconfig.yaml` once the
server is up. Point kubectl at it:

```bash
export KUBECONFIG=$(pwd)/kubeconfig/kubeconfig.yaml
kubectl get nodes
```

## Notes

- `privileged: true` is required for k3s to manage its own containerd/network — this is expected for a local dev cluster, not something to also do in production.
- This is a single-node cluster for development/testing — see the `Kubernautes` command reference (in the Integrated-Service bundle) for managing a real multi-node production cluster.
