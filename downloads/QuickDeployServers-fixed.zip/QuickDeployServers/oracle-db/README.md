# Oracle DB Free — quick deploy

Oracle Database Free (23ai) in a container, plus a Flask service that
proves connectivity.

## One-time setup

Oracle's container registry requires accepting their license before you
can pull the image:

```bash
docker login container-registry.oracle.com
# accept the license at https://container-registry.oracle.com first if prompted
```

## Run

```bash
cp .env.example .env   # set ORACLE_PWD
docker compose up --build
```

First boot takes a few minutes while the database initializes.

`curl http://localhost:8080/db-check` returns the server version once
it's up and reachable.

## Notes

- Default `system` user is used for the connectivity check only — create
  a dedicated application user/schema for real workloads, don't run app
  traffic through `system`.
- Data persists in the `oracle_data` volume.
