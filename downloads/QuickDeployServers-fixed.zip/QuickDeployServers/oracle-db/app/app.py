"""Connectivity check for the quick-deployed Oracle DB Free instance.
Uses python-oracledb's thin mode, so no Oracle Instant Client install
is required.
"""
import os

from flask import Flask, jsonify
import oracledb

app = Flask(__name__)


@app.route("/health", methods=["GET"])
def health():
    return jsonify({"status": "ok"}), 200


@app.route("/db-check", methods=["GET"])
def db_check():
    dsn = f"{os.environ['DB_HOST']}:{os.environ['DB_PORT']}/{os.environ['DB_SERVICE']}"
    try:
        conn = oracledb.connect(
            user=os.environ["DB_USER"],
            password=os.environ["DB_PASSWORD"],
            dsn=dsn,
        )
        with conn.cursor() as cur:
            cur.execute("SELECT banner FROM v$version WHERE ROWNUM = 1")
            version = cur.fetchone()[0]
        conn.close()
        return jsonify({"connected": True, "server_version": version}), 200
    except Exception as e:
        return jsonify({"connected": False, "error": str(e)}), 500


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8080)
