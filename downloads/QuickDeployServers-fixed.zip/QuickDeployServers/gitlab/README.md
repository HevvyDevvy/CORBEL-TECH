# GitLab CE — quick deploy

Self-hosted GitLab in one command, with signup disabled, git-over-HTTP
brute-force protection (rack_attack), and the root password set from an
env var instead of GitLab's random-password-in-a-file default.

## Run

```bash
cp .env.example .env   # set GITLAB_ROOT_PASSWORD
docker compose up -d
```

First boot takes a few minutes (GitLab reconfigures itself on startup).
Watch progress with:

```bash
docker compose logs -f gitlab
```

Then visit http://localhost:8929 and log in as `root` with the password
from `.env`.

## Notes

- SSH for git clones is on the host port set by `GITLAB_SSH_PORT` (default 2224, not 22, to avoid clashing with the host's own SSH).
- Data persists in the `gitlab_config`/`gitlab_logs`/`gitlab_data` named volumes — back those up, not just the compose file.
- For real deployment, put this behind the nginx TLS-terminating proxy from the H2C_Servers repo rather than exposing port 8929 directly.
