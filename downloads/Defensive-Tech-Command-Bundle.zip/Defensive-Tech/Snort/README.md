# Snort — Quick-Fire Commands

Open-source IDS/IPS (Snort 3).

#### 1. Install & Verify

```bash
sudo apt install snort
snort -V
```

#### 2. Config & Validate

```bash
sudo nano /etc/snort/snort.lua        # Snort 3 uses Lua config (snort.conf for Snort 2)
snort -c /etc/snort/snort.lua -T      # test config
```

#### 3. Run Modes

```bash
# Sniffer mode (just print packets)
sudo snort -v -i eth0

# IDS mode with a rules file, logging alerts
sudo snort -c /etc/snort/snort.lua -i eth0 -A alert_fast -l /var/log/snort/

# Offline pcap
sudo snort -c /etc/snort/snort.lua -r capture.pcap -A alert_fast

# Inline IPS mode (requires AF_PACKET/NFQ inline interface pair)
sudo snort -c /etc/snort/snort.lua -Q --daq afpacket -i eth0:eth1
```

#### 4. Rules Management (Snort 2 legacy `pulledpork`, Snort 3 native)

```bash
sudo pulledpork.pl -c /etc/snort/pulledpork.conf -l
snort --rule-to-hex "alert tcp any any -> any 80 (msg:\"test\"; sid:1000001;)"
```

#### 5. Logs & Alerts

```bash
tail -f /var/log/snort/alert
sudo u2spewfoo /var/log/snort/snort.log.*   # decode unified2 binary logs
```

#### 6. Common Flags

```bash
snort -c snort.lua -i eth0 -k none    # disable checksum validation (common in VM/test labs)
snort -c snort.lua --daq-list          # list available DAQ modules
snort --version
```

#### 7. Useful One-Liners

```bash
# Count alerts by signature today
awk '/\[\*\*\]/{print $4, $5}' /var/log/snort/alert | sort | uniq -c | sort -rn | head

# Validate a single rule file syntax only
snort -c /etc/snort/snort.lua -R /path/to/local.rules --lint
```
