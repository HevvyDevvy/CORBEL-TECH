# Splunk — Quick-Fire Commands & SPL

#### 1. Service Management (CLI)

```bash
sudo /opt/splunk/bin/splunk start
sudo /opt/splunk/bin/splunk stop
sudo /opt/splunk/bin/splunk restart
sudo /opt/splunk/bin/splunk status
sudo /opt/splunk/bin/splunk enable boot-start
```

#### 2. Index & Data Management

```bash
splunk add index my_index
splunk list index
splunk add monitor /var/log/myapp.log -index my_index -sourcetype my_sourcetype
splunk add forward-server <indexer-host>:9997     # on a forwarder
```

#### 3. User & Auth

```bash
splunk add user analyst -role user -password '<password>'
splunk edit user admin -password '<new-password>'
splunk list user
```

#### 4. Core SPL — Search Basics

```spl
index=main sourcetype=access_combined status=500
| stats count by clientip
| sort -count
```

```spl
index=security sourcetype=linux_secure "Failed password"
| rex field=_raw "Failed password for (invalid user )?(?<user>\S+) from (?<src_ip>\S+)"
| stats count by user, src_ip
| where count > 10
```

#### 5. Time & Field Manipulation

```spl
index=main earliest=-24h@h latest=now
| eval hour=strftime(_time, "%H")
| timechart span=1h count
```

#### 6. Lookups & Enrichment

```spl
index=main
| lookup asset_inventory ip AS src_ip OUTPUT owner, department
| table _time, src_ip, owner, department
```

#### 7. Alerting (savedsearch via CLI)

```bash
splunk search "index=security | stats count by src_ip | where count > 100" \
  -auth admin:<password>

# Or manage saved searches directly
curl -k -u admin:<password> https://localhost:8089/services/saved/searches
```

#### 8. Common Transforming Commands

```spl
| top limit=10 src_ip
| rare src_ip
| dedup user
| transaction user maxspan=5m
| eventstats avg(bytes) as avg_bytes by host
```

#### 9. Useful One-Liners

```spl
# Failed logon spike detection
index=wineventlog EventCode=4625
| bucket _time span=5m
| stats count by _time, Account_Name
| where count > 5

# Rare processes (hunting)
index=sysmon EventCode=1
| stats count by CommandLine
| where count < 3
```
