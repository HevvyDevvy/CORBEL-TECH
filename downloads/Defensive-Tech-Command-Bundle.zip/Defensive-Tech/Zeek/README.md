# Zeek — Quick-Fire Commands

Network security monitor (protocol-aware logging, not signature-based like Suricata/Snort).

#### 1. Install & Verify

```bash
sudo apt install zeek
export PATH=/opt/zeek/bin:$PATH
zeek --version
```

#### 2. ZeekControl (production deployment)

```bash
sudo zeekctl
> deploy          # check config, install, and start
> status
> stop
> start
> diag            # dump recent crash diagnostics
```

Config lives in `/opt/zeek/etc/node.cfg` (workers/proxy/manager topology) and `networks.cfg` (monitored CIDR ranges).

#### 3. Run Modes (standalone / ad hoc)

```bash
# Live capture
sudo zeek -i eth0

# Offline pcap
zeek -r capture.pcap

# With a specific script/policy loaded
zeek -r capture.pcap local
```

#### 4. Logs

Zeek writes structured, tab-separated logs per protocol, not one big alert feed.

```bash
ls *.log
# conn.log dns.log http.log ssl.log x509.log notice.log weird.log files.log ...

# Human-readable columns
zeek-cut id.orig_h id.resp_h id.resp_p proto service < conn.log

# Only flagged "notice" events (Zeek's closest equivalent to an alert)
cat notice.log | zeek-cut note msg sub
```

#### 5. Useful One-Liners

```bash
# Top talkers by bytes
cat conn.log | zeek-cut id.orig_h orig_bytes | awk '{sum[$1]+=$2} END {for (ip in sum) print sum[ip], ip}' | sort -rn | head

# All DNS queries for a domain
cat dns.log | zeek-cut query | grep "example.com"

# JSON output instead of TSV (easier for jq/SIEM ingestion)
zeek -r capture.pcap LogAscii::use_json=T
```

#### 6. Scripting

```bash
zeek -r capture.pcap /path/to/custom-script.zeek
zeekctl check   # validate custom scripts before deploy
```
