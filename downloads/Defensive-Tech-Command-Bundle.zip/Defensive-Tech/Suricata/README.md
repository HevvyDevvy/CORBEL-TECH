# Suricata — Quick-Fire Commands

Open-source IDS/IPS/NSM engine.

#### 1. Install & Service

```bash
sudo apt install suricata
sudo systemctl enable --now suricata
sudo systemctl status suricata
```

#### 2. Config & Validate

```bash
sudo nano /etc/suricata/suricata.yaml
sudo suricata -T -c /etc/suricata/suricata.yaml -v   # test config
```

#### 3. Run Modes

```bash
# Live capture on an interface
sudo suricata -c /etc/suricata/suricata.yaml -i eth0

# Offline pcap analysis
sudo suricata -c /etc/suricata/suricata.yaml -r capture.pcap -l /var/log/suricata/

# AF_PACKET IPS mode (inline, two interfaces)
sudo suricata -c /etc/suricata/suricata.yaml --af-packet
```

#### 4. Rules Management (suricata-update)

```bash
sudo suricata-update                     # fetch/apply Emerging Threats Open ruleset
sudo suricata-update list-sources
sudo suricata-update enable-source et/open
sudo suricata-update update-sources
sudo suricata-update --reload-command "systemctl reload suricata"
```

#### 5. Logs & Alerts

```bash
tail -f /var/log/suricata/fast.log
tail -f /var/log/suricata/eve.json | jq .

# Filter eve.json for alerts only
jq 'select(.event_type=="alert")' /var/log/suricata/eve.json
```

#### 6. Testing a Rule Fires

```bash
# Built-in test rule (SID 2100498) fires on any traffic containing "GET"
curl http://testmynids.org/uid/index.html
grep "GPL ATTACK_RESPONSE" /var/log/suricata/fast.log
```

#### 7. Useful One-Liners

```bash
# Top alerting signatures today
jq -r 'select(.event_type=="alert") | .alert.signature' /var/log/suricata/eve.json | sort | uniq -c | sort -rn | head

# Reload rules without restarting (keeps existing connections tracked)
sudo kill -USR2 $(pidof suricata)
```
