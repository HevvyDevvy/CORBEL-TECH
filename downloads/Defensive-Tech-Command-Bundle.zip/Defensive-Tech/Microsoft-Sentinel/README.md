# Microsoft Sentinel — Quick-Fire KQL & Azure CLI

Cloud-native SIEM/SOAR. Sentinel itself is queried via KQL (Kusto Query
Language), not a shell — management is via Azure CLI/PowerShell.

#### 1. Workspace Management (Azure CLI)

```bash
az login
az monitor log-analytics workspace list --resource-group <rg>
az sentinel alert-rule list --resource-group <rg> --workspace-name <ws>
```

#### 2. Core KQL Patterns

```kql
// Basic filter + time range
SecurityEvent
| where TimeGenerated > ago(24h)
| where EventID == 4625              // failed logon

// Failed RDP/logon brute-force detection
SecurityEvent
| where EventID == 4625
| summarize FailCount = count() by Account, IpAddress, bin(TimeGenerated, 5m)
| where FailCount > 10

// Sign-in anomalies (Azure AD)
SigninLogs
| where ResultType != "0"
| summarize Attempts = count() by UserPrincipalName, IPAddress
| order by Attempts desc
```

#### 3. Threat Hunting

```kql
// Process creation matching a suspicious pattern
DeviceProcessEvents
| where ProcessCommandLine has_any ("powershell -enc", "certutil -decode", "mshta")
| project Timestamp, DeviceName, AccountName, ProcessCommandLine

// Rare processes (needle-in-haystack)
DeviceProcessEvents
| summarize Count = count() by ProcessCommandLine
| where Count < 3
```

#### 4. Watchlists & Enrichment

```kql
_GetWatchlist('HighValueAssets')
| join kind=inner (SecurityEvent) on $left.Hostname == $right.Computer
```

#### 5. Incident/Automation (Azure CLI)

```bash
az sentinel incident list --resource-group <rg> --workspace-name <ws>
az sentinel incident update --resource-group <rg> --workspace-name <ws> --incident-id <id> --status Closed
az sentinel automation-rule list --resource-group <rg> --workspace-name <ws>
```

#### 6. Analytics Rule Management

```bash
az sentinel alert-rule create --resource-group <rg> --workspace-name <ws> \
  --rule-id <guid> --kind Scheduled \
  --display-name "Brute force detection" \
  --severity High --query "SecurityEvent | where EventID == 4625" \
  --query-frequency PT5M --query-period PT5M --trigger-threshold 10
```

#### 7. Useful KQL Functions

```kql
| summarize count() by bin(TimeGenerated, 1h)     // time-bucketed counts
| render timechart                                // visualize in the portal
| extend GeoInfo = geo_info_from_ip_address(IPAddress)
| parse EventData with * "TargetUserName=" User "," *
```
