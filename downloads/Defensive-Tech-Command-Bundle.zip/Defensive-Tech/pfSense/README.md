# pfSense — Quick-Fire Commands

FreeBSD-based firewall/router. Most day-to-day config is via the web
GUI, but the console/shell (option 8, "Shell") gives direct access.

#### 1. Console Menu (serial/direct access)

```
1) Logout
2) Assign Interfaces
6) Reboot
7) Ping host
8) Shell
11) Restore recent configuration
16) Restart PHP-FPM
```

#### 2. pfctl (the underlying PF firewall)

```bash
pfctl -s rules                # show active ruleset
pfctl -s nat                  # show NAT rules
pfctl -s state                # show current state table
pfctl -f /tmp/rules.debug     # load a ruleset from file
pfctl -d                      # disable packet filtering (careful!)
pfctl -e                      # re-enable
```

#### 3. Config Backup/Restore (CLI)

```bash
cp /cf/conf/config.xml /root/config-backup-$(date +%F).xml
# Restore: place config.xml at /cf/conf/config.xml, then reboot
```

#### 4. Diagnostics

```bash
tcpdump -i igb0 -n
netstat -rn                   # routing table
top
ifconfig
```

#### 5. Logs

```bash
clog /var/log/filter.log | tail -50     # firewall log (circular log format)
clog /var/log/system.log | tail -50
tail -f /var/log/gateways.log
```

#### 6. Package/CLI Management

```bash
pkg info                      # installed packages
pkg install <pkg-name>
pfSense-upgrade -c             # check for pfSense updates
pfSense-upgrade                # apply updates
```

#### 7. WAN/Gateway Diagnostics

```bash
dpinger -S                    # gateway monitoring daemon status
route -n get default
```

#### 8. Useful One-Liners

```bash
# Live-tail blocked traffic
clog -f /var/log/filter.log | grep block

# Show all states from a specific source IP
pfctl -s state | grep 192.168.1.50
```
