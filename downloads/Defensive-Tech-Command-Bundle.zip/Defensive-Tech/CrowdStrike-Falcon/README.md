# CrowdStrike Falcon — Quick-Fire Commands

EDR/XDR platform. Endpoint agent (falconctl) + cloud API (Falcon
Query Language for Event Search, REST API for everything else).

#### 1. Agent (falconctl) — Linux

```bash
sudo /opt/CrowdStrike/falconctl -g --cid          # show configured Customer ID
sudo /opt/CrowdStrike/falconctl -s --cid=<CID>    # set CID (initial install)
sudo /opt/CrowdStrike/falconctl -g --aid           # show Agent ID
sudo systemctl status falcon-sensor
sudo systemctl restart falcon-sensor
```

#### 2. Agent — Windows (PowerShell)

```powershell
Get-Service CSFalconService
Restart-Service CSFalconService
& "C:\Program Files\CrowdStrike\CSSensorSettings.exe" -g --cid
```

#### 3. Agent — macOS

```bash
sudo /Applications/Falcon.app/Contents/Resources/falconctl stats
sudo /Applications/Falcon.app/Contents/Resources/falconctl license
```

#### 4. Falcon API — Auth

```bash
curl -X POST "https://api.crowdstrike.com/oauth2/token" \
  -d "client_id=<id>&client_secret=<secret>" \
  -H "Content-Type: application/x-www-form-urlencoded"
```

#### 5. Detections & Incidents (API)

```bash
curl -H "Authorization: Bearer <token>" \
  "https://api.crowdstrike.com/detects/queries/detects/v1?filter=status:'new'"

curl -H "Authorization: Bearer <token>" \
  "https://api.crowdstrike.com/incidents/queries/incidents/v1"
```

#### 6. Real Time Response (RTR) — remote shell to an endpoint

```bash
# Start a session (API)
curl -X POST -H "Authorization: Bearer <token>" \
  "https://api.crowdstrike.com/real-time-response/entities/sessions/v1" \
  -d '{"device_id": "<aid>"}'

# Common RTR commands once in-session (via console or API command execution)
ls
cd C:\Users
ps
netstat
get <file-path>              # retrieve a file for analysis
```

#### 7. Falcon Query Language (Event Search)

```
event_simpleName=ProcessRollup2
| where CommandLine=/powershell.*-enc/i
| table ComputerName, CommandLine, UserName
```

#### 8. Useful One-Liners

```bash
# Host search by hostname
curl -H "Authorization: Bearer <token>" \
  "https://api.crowdstrike.com/devices/queries/devices/v1?filter=hostname:'WKS-01'"

# Contain a host (network isolation)
curl -X POST -H "Authorization: Bearer <token>" \
  "https://api.crowdstrike.com/devices/entities/devices-actions/v2?action_name=contain" \
  -d '{"ids": ["<aid>"]}'
```
