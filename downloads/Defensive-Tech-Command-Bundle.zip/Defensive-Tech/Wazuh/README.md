# Wazuh — Quick-Fire Commands

Open-source SIEM/XDR — manager + agents, built on the Elastic stack.

#### 1. Manager Service

```bash
sudo systemctl status wazuh-manager
sudo systemctl restart wazuh-manager
sudo /var/ossec/bin/wazuh-control status
sudo /var/ossec/bin/wazuh-control restart
```

#### 2. Agent Management (on the manager)

```bash
sudo /var/ossec/bin/manage_agents          # interactive add/remove/extract-key
sudo /var/ossec/bin/agent_control -l       # list connected agents
sudo /var/ossec/bin/agent_control -i <id>  # info on a specific agent
sudo /var/ossec/bin/agent_control -r -u <id>  # restart an agent remotely
```

#### 3. Agent Side

```bash
sudo systemctl status wazuh-agent
sudo /var/ossec/bin/agent-auth -m <manager-ip>   # enroll with the manager
sudo systemctl restart wazuh-agent
```

#### 4. Rules & Decoders

```bash
sudo /var/ossec/bin/wazuh-logtest              # test a log line against loaded rules interactively
sudo nano /var/ossec/etc/rules/local_rules.xml
sudo nano /var/ossec/etc/decoders/local_decoder.xml
sudo systemctl restart wazuh-manager           # required after rule/decoder changes
```

#### 5. Logs

```bash
tail -f /var/ossec/logs/alerts/alerts.log
tail -f /var/ossec/logs/alerts/alerts.json | jq .
tail -f /var/ossec/logs/ossec.log              # manager's own operational log
```

#### 6. API (for automation/dashboards)

```bash
curl -u wazuh:<password> -k -X POST "https://localhost:55000/security/user/authenticate"
curl -k -H "Authorization: Bearer <token>" "https://localhost:55000/agents?status=active"
```

#### 7. File Integrity Monitoring (Syscheck)

```bash
sudo /var/ossec/bin/wazuh-control status | grep syscheckd
sudo /var/ossec/bin/agent_control -r -u <id>   # force a syscheck re-scan on an agent
```

#### 8. Useful One-Liners

```bash
# Top rule IDs firing today
jq -r '.rule.id' /var/ossec/logs/alerts/alerts.json | sort | uniq -c | sort -rn | head

# Alerts above a severity level
jq 'select(.rule.level >= 10)' /var/ossec/logs/alerts/alerts.json
```
