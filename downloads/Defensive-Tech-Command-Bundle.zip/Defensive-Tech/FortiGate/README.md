# FortiGate (FortiOS) — Quick-Fire Commands

Fortinet's next-gen firewall CLI.

#### 1. Basic Navigation

```bash
config global                 # enter global config context (multi-VDOM units)
config vdom
edit root

get system status
show full-configuration
execute reboot
```

#### 2. Interfaces

```bash
config system interface
edit "port1"
set ip 192.168.1.1 255.255.255.0
set allowaccess ping https ssh
next
end

get system interface physical
diagnose hardware deviceinfo nic port1
```

#### 3. Firewall Policies

```bash
config firewall policy
edit 0
set srcintf "port1"
set dstintf "port2"
set srcaddr "all"
set dstaddr "all"
set action accept
set schedule "always"
set service "ALL"
set nat enable
next
end

show firewall policy
diagnose firewall iprope list 100004
```

#### 4. Security Profiles (IPS/AV/Web Filter)

```bash
config ips sensor
edit "default"
end

config antivirus profile
edit "default"
end

diagnose ips signature list
diagnose test application ipsmonitor 99   # IPS engine stats
```

#### 5. VPN

```bash
get vpn ipsec tunnel summary
diagnose vpn ike gateway list
diagnose vpn tunnel list
execute vpn ipsec tunnel down <tunnel-name>
execute vpn ipsec tunnel up <tunnel-name>
```

#### 6. Logging & Diagnostics

```bash
execute log filter category 0        # traffic logs
execute log display

diagnose sniffer packet any "host 8.8.8.8" 4
diagnose debug flow filter addr 192.168.1.10
diagnose debug flow trace start 20
diagnose debug enable
```

#### 7. High Availability

```bash
get system ha status
diagnose sys ha status
execute ha failover set enable
```

#### 8. Backup / Restore

```bash
execute backup config flash
execute restore config flash <filename>
```
