"""Generate a GPT chat transcript and upload it to Google Drive.

Fixes from the original:
- Replaced the removed `openai.Completion.create` / `text-davinci-004`
  call (davinci-completion models are retired) with the current
  ChatCompletion-style client.
- Added the missing `MediaFileUpload` import.
- Added a requirements.txt (see alongside this file).
"""
import os

from openai import OpenAI
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from google.auth.transport.requests import Request
from googleapiclient.discovery import build
from googleapiclient.http import MediaFileUpload

SCOPES = ["https://www.googleapis.com/auth/drive.file"]
client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))


def get_credentials():
    creds = None
    if os.path.exists("token.json"):
        creds = Credentials.from_authorized_user_file("token.json", SCOPES)
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            flow = InstalledAppFlow.from_client_secrets_file("credentials.json", SCOPES)
            creds = flow.run_local_server(port=0)
        with open("token.json", "w") as token:
            token.write(creds.to_json())
    return creds


def upload_to_drive(creds, file_name):
    service = build("drive", "v3", credentials=creds)
    file_metadata = {"name": file_name}
    media = MediaFileUpload(file_name, mimetype="text/plain")
    file = service.files().create(body=file_metadata, media_body=media, fields="id").execute()
    print(f"File ID: {file.get('id')}")


def save_chat_to_drive(prompt: str = "Explain the importance of cloud computing in modern businesses."):
    response = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[{"role": "user", "content": prompt}],
        max_tokens=150,
    )
    chat_transcript = response.choices[0].message.content.strip()

    file_name = "GPT_Chat_Transcript.txt"
    with open(file_name, "w") as f:
        f.write(chat_transcript)

    creds = get_credentials()
    upload_to_drive(creds, file_name)
    os.remove(file_name)


if __name__ == "__main__":
    save_chat_to_drive()
